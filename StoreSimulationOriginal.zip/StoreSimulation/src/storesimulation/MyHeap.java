/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package storesimulation;

import java.util.ArrayList;

/**
 *
 * @author timmermank1
 */
class MyHeap{
    //You do not need to resize this.
   Event[] myHeap =  new Event[5000];  
    

    int getSize() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Event remove() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void insert(Event item) {
       //Event has an isFirst method to help compare event times
    }
    
}
